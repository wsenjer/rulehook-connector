=== WooCommerce Simple Table Rates Pro ===
Contributors: waseem_senjer, wprubyplugins
Donate link: https://wpruby.com
Tags: woocommerce, shipping, table rates
Requires at least: 4.0
Tested up to: 6.8
Stable tag: 2.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Offer flexible shipping to your customers based on many rules.

== Description ==

WooCommerce Simple Table Rates Pro is a WooCommerce extension which allows you to set shipping prices based on many rules such as weight, price, dimensions, user roles and much more.


== Installation ==

1. Upload `woocommerce-simple-table-rates-pro` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to WooCommerce -> Settings -> Shipping.
4. Add `Simple Table Rates` to the shipping zones.

== Changelog ==
= 2.0.6 =
* Fixed: PHP fatal error when there is an empty product rule.

= 2.0.5 =
* Fixed: PHP fatal error if actions are used.
* Fixed: Licence activation page URL was not working.

= 2.0.4 =
Fixed: PHP fatal error when there is an empty action.
Fixed: PHP warnings.
Added: Shipping method description.

= 2.0.3 =
Fixed: Product rule was being saved incorrectly.
Fixed: Product Category rule was not matched for variant products.
Fixed: Product Tag rule was not matched for variant products.

= 2.0.2 =
Fixed: Handling fees were only applied as integer value.

= 2.0.1 =
Fixed: only integer numbers were allowed in the price field.

= 2.0.0 =
* Added: Payment Method Rule
* Added: Product Attribute Rule
* Added: Product Stock Status Rule

= 1.1.0 =
* Added: Highest and Lowes Calculations method.
* Added: Check if WooCommerce is active.

= 1.0.2 =
* Fixed: Update was not working, filename changed.

= 1.0.1 =
* Added: Hide other methods action.
* Fixed: Rules table layout.

= 1.0.0 =
* Initial Release
