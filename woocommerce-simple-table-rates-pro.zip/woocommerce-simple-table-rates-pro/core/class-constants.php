<?php

namespace WPRuby_Table_Rates\Core;

class Constants {
	const UTIL_CURRENT_VERSION = '2.0.6';
	const UTIL_STORE_URL = 'https://wpruby.com/edd_sl/woocommerce-simple-table-rates-pro';
	const UTIL_WPRUBY_ITEM_ID = 81227;
	const UTIL_LICENSE_KEY = 'simple_table_rates_pro_license_key';
}
