<tr style="vertical-align: top;">
    <th class="titledesc">
        <label><?php _e('Rules', 'simple-table-rates') ?></label>
    </th>
    <td class="forminp">
        <fieldset id="str_rules">
        </fieldset>
    </td>
</tr>
