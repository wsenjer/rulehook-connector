<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Product_Attribute_Rule extends Abstract_Rule {

	public $attribute = '';
	public $term = '';

	public function match( array $package ): bool {
		return in_array($this->term, $this->get_attribute_terms($package));
	}

	private function get_attribute_terms(array $package): array
	{
		$terms = [];

		foreach ($package['contents'] as $item) {
			/** @var WC_Product $product */
			$product = $item['data'];
			$terms[] = $product->get_attribute( $this->attribute );
		}

		return $terms;

	}

}
