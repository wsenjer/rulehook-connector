<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Coupon_Rule extends Abstract_Rule {

	public $coupon = '';

	public function match(array $package ): bool
	{
		if (!isset($package['applied_coupons'])) {
			return false;
		}

		if (empty($package['applied_coupons'])) {
			return false;
		}

		$coupons = array_map('strtolower', $package['applied_coupons']);

		return in_array(strtolower($this->coupon), $coupons);

	}

}
