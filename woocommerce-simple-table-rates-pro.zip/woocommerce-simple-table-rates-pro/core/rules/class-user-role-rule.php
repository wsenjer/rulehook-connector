<?php

namespace WPRuby_Table_Rates\Core\Rules;

class User_Role_Rule extends Abstract_Rule {

	public $role = '';

	public function match( array $package ): bool {
		if ( ! isset( $package['user'] ) ) {
			return false;
		}

		if ( ! isset( $package['user']['ID'] ) ) {
			return false;
		}

		$user_id = $package['user']['ID'];

		$user_meta = get_userdata( intval( $user_id ) );

		return in_array( $this->role, $user_meta->roles );
	}
}
