<?php

namespace WPRuby_Table_Rates\Core\Rules;

interface Interface_Rule {

	public function match(array $package): bool;
}
