<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Payment_Method_Rule extends Abstract_Rule {

	public $payment_method = '';

	public function match(array $package ): bool
	{
		$chosen_payment_method = WC()->session->get('chosen_payment_method');

		return $this->payment_method === $chosen_payment_method;
	}

}
