<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Day_Of_Week_Rule extends Abstract_Rule {

	public $day = -1;

	public function match( array $package ): bool
	{
		return intval( date('N')) === intval($this->day);
	}

}
