<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Time_Of_Day_Rule extends Abstract_Rule {

	public $time_from = '';
	public $time_to = '';

	public function match(array $package ): bool
	{
		$time_now = strtotime( date('H:i:s'));
		$from = strtotime($this->time_from);
		$to = strtotime($this->time_to);

		return $this->between($time_now, $from, $to);
	}



}
