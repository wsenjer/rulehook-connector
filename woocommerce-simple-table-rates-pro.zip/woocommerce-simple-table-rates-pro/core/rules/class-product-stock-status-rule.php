<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Product_Stock_Status_Rule extends Abstract_Rule {

	public $stock_status = 0;

	public function match( array $package ): bool {
		return in_array($this->stock_status, $this->get_stock_statuses($package));
	}

	private function get_stock_statuses(array $package): array
	{
		$stock_statuses = [];

		foreach ($package['contents'] as $item) {
			/** @var WC_Product $product */
			$product = $item['data'];
			$stock_statuses[] = $product->get_stock_status();
		}

		return $stock_statuses;

	}

}
