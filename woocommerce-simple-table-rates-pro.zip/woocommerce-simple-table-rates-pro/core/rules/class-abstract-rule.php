<?php

namespace WPRuby_Table_Rates\Core\Rules;

use WPRuby_Table_Rates\Core\Actions\Abstract_Action;
use WPRuby_Table_Rates\Core\Actions\Actions_Factory;

abstract class Abstract_Rule implements Interface_Rule {

	protected $id = -1;

	protected $price = 0.0;

	/** @var array<Abstract_Action>  */
	protected $actions = [];

	/**
	 * @return int
	 */
	public function getId(): int {
		return $this->id;
	}

	/**
	 * @param int $id
	 *
	 * @return Abstract_Rule
	 */
	public function setId( int $id ): Abstract_Rule {
		$this->id = $id;

		return $this;
	}

	public function setPrice(float $price): self
	{
		$this->price = $price;
		return $this;
	}

	public function getPrice(): float
	{
		return $this->price;
	}



	public function getActions() :array
	{
		return $this->actions;
	}

	public function populateActions(array $actions): self
	{
		foreach ($actions as $action) {

			$actionObject = Actions_Factory::make($action['action']);

            if (is_null($actionObject)) {
                continue;
            }

			$actionObject->payload = $action['value'];
			$actionObject->rule_id = $this->getId();
			$this->actions[] = $actionObject;

		}

		return $this;
	}

	public function populate(array $data): self
	{
		foreach ($data as $key => $value) {
			if ($this instanceof Product_Rule && !empty($value['code'])) {
				$this->products[] = $value['code'];
			}
			elseif (property_exists($this, $key)) {
				$this->$key = $value;
			}
		}

		return $this;
	}

	protected function between(float $value, float $from, float $to) :bool
	{
		return $value >= $from && $value <= $to;
	}

	protected function get_real_product_id($product)
	{
		$product_id = $product->get_id();

		if ( $product->get_parent_id() > 0 ) {
			return $product->get_parent_id();
		}

		return $product_id;
	}

}
