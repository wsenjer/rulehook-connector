<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Product_Category_Rule extends Abstract_Rule {

	public $category = 0;

	public function match( array $package ): bool {
		return in_array($this->category, $this->get_categories_ids($package));
	}

	private function get_categories_ids(array $package): array
	{
		$categories_ids = [];

		foreach ($package['contents'] as $item) {
			/** @var WC_Product $product */
			$product = $item['data'];
			$product_id = $this->get_real_product_id($product);

			$product_categories = get_the_terms( $product_id, 'product_cat' );
			if ( ! $product_categories ) {
				continue;
			}

			$product_categories = array_map(
				function ( $term ) {
					return $term->term_id;
				},
				$product_categories
			);
			$categories_ids = array_merge($categories_ids, $product_categories);
		}

		return $categories_ids;

	}

}
