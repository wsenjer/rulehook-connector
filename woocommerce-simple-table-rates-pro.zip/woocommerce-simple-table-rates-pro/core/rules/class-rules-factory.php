<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Rules_Factory {

	public static function make( array $rule ): Abstract_Rule {
		$rules = [
			'weight'               => Weight_Rule::class,
			'cart_total'           => Cart_Total_Rule::class,
			'product'              => Product_Rule::class,
			'quantity'             => Quantity_Rule::class,
			'volume'               => Volume_Rule::class,
			'total_dimensions'     => Total_Dimensions_Rule::class,
			'product_category'     => Product_Category_Rule::class,
			'product_tag'          => Product_Tag_Rule::class,
			'shipping_class'       => Shipping_Class_Rule::class,
			'user_role'            => User_Role_Rule::class,
			'time_of_day'          => Time_Of_Day_Rule::class,
			'day_of_week'          => Day_Of_Week_Rule::class,
			'coupon'               => Coupon_Rule::class,
			'payment_method'       => Payment_Method_Rule::class,
			'product_stock_status' => Product_Stock_Status_Rule::class,
			'product_attribute'    => Product_Attribute_Rule::class,
		];

		return new $rules[ $rule['type'] ];
	}

}
