<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Product_Tag_Rule extends Abstract_Rule {

	public $tag = 0;

	public function match(array $package ): bool {
		return in_array($this->tag, $this->get_tags_ids($package));
	}

	private function get_tags_ids(array $package): array
	{
		$tags_ids = [];

		foreach ($package['contents'] as $item) {
			/** @var WC_Product $product */
			$product = $item['data'];
            $product_id = $this->get_real_product_id($product);

            $product_tags = get_the_terms( $product_id, 'product_tag' );
            if ( ! $product_tags ) {
                continue;
            }

            $product_tags = array_map(
                function ( $term ) {
                    return $term->term_id;
                },
                $product_tags
            );

			$tags_ids = array_merge($tags_ids, $product_tags);
		}

		return $tags_ids;

	}

}
