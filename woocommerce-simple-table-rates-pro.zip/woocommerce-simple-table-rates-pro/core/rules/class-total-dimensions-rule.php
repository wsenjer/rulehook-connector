<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Total_Dimensions_Rule extends Abstract_Rule {

	public $dimensions_from = 0;
	public $dimensions_to = 0;

	public function match(array $package ): bool {
		return $this->between($this->get_total_dimensions($package), $this->dimensions_from, $this->dimensions_to);
	}

	private function get_total_dimensions(array $package): float
	{
		$total_dimensions = 0;

		foreach ($package['contents'] as $item) {
			/** @var WC_Product $product */
			$product = $item['data'];
			if (!$product->has_dimensions()) continue;
			$product_total_dimensions = array_sum(array_values($product->get_dimensions(false)));
			$total_dimensions += round($product_total_dimensions * $item['quantity'], 2);
		}

		return $total_dimensions;

	}

}
