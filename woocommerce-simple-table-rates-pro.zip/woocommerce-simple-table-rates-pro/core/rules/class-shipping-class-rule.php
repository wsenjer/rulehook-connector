<?php

namespace WPRuby_Table_Rates\Core\Rules;

class Shipping_Class_Rule extends Abstract_Rule {

	public $shipping_class = 0;

	public function match(array $package ): bool
	{
		return in_array($this->shipping_class, $this->get_shipping_classes($package));
	}

	private function get_shipping_classes(array $package): array
	{
		$shipping_classes_ids = [];

		foreach ($package['contents'] as $item) {
			/** @var WC_Product $product */
			$product = $item['data'];
			$shipping_class = $product->get_shipping_class_id();
			$shipping_classes_ids[] = $shipping_class;
		}

		return $shipping_classes_ids;

	}

}
