<?php
namespace WPRuby_Table_Rates\Core;


use WPRuby_Table_Rates\Core\App\Endpoints\Endpoints_Factory;
use WPRuby_Table_Rates\Core\App\Frontend\App_Page;
use WPRuby_Table_Rates\Core\License\Handler;
use WPRuby_Table_Rates\Core\License\Updater;

class Core {

	private static $_instance;

	/**
	 * @return self
	 */
	public static function get_instance()
	{
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function __construct()
	{
		if (!$this->is_woocommerce_active()) {
			return;
		}

		App_Page::get_instance();
		Endpoints_Factory::boot();
		$this->load_hooks();
	}

	private function load_hooks()
	{
		add_filter( 'woocommerce_shipping_methods', [$this, 'add_shipping_method'] );
		add_action( 'woocommerce_shipping_init', [$this, 'init_shipping_method'] );
		add_action('wp_loaded', [$this, 'license_handler']);
		add_action('admin_init', [$this, 'plugin_updater']);

	}

	public function add_shipping_method( $methods )
	{
		$methods['simple_table_rates'] = Shipping_Method::class;
		return $methods;
	}


	public function init_shipping_method()
	{
		require_once plugin_dir_path( __FILE__ ) . 'class-shipping-method.php';
	}

	public function license_handler()
	{
		$license_handler = new Handler(
			Constants::UTIL_LICENSE_KEY,
			Constants::UTIL_STORE_URL,
			admin_url('admin.php?page=wc-settings&tab=shipping'));
		$license_handler->setPluginName('WooCommerce Simple Table Rates Pro');
	}

	public function plugin_updater()
	{
		$plugin_file = 'woocommerce-simple-table-rates-pro/simple-table-rates-pro.php';

		new Updater(Constants::UTIL_STORE_URL, $plugin_file, [
			'version' 	=> Constants::UTIL_CURRENT_VERSION,
			'license' 	=> trim(get_option(Constants::UTIL_LICENSE_KEY)),
			'item_id'     => Constants::UTIL_WPRUBY_ITEM_ID,
			'author' 	=> 'Waseem Senjer',	// author of this plugin
			'url'           => home_url()
		],
			admin_url('admin.php?page=woocommerce-simple-table-rates-pro-activation')
		);
	}

	private function is_woocommerce_active() :bool
	{
		return $this->is_plugin_active('woocommerce/woocommerce.php');
	}

	private function is_plugin_active(string $slug) :bool
	{
		$active_plugins = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() )
			$active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );
		return in_array( $slug, $active_plugins ) || array_key_exists( $slug, $active_plugins );
	}

}
