<?php

namespace WPRuby_Table_Rates\Core\Actions;

class Cancel_Action extends Abstract_Action {

	public function execute()
	{
	}

}
